# AlgoTrade Studio (Vercel, Live GPT)
Upload this ZIP to Vercel (Dashboard → Upload). Then set env var:
OPENAI_API_KEY = your OpenAI key

index.html → UI (Hebrew, purple)
api/generate.ts → serverless GPT bridge returning {code, summary, tips}
